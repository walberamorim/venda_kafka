from flask import Flask, Response, request

from kafka import KafkaClient, KafkaProducer
from kafka.errors import KafkaError

from time import sleep
import secrets
import random
import string
import json

PROCESSO = "ebook"
servico = Flask(PROCESSO)

INFO = {
    "descricao": "serviço para venda de ebooks",
    "versao":  "0.0.1"
}

def iniciar():
    iniciado = False

    try:
        cliente = KafkaClient(bootstrap_servers = ["kafka:29092"], api_version=(0, 10, 1))
        cliente.add_topic(PROCESSO)
        cliente.close()

        iniciado = True
    except Exception as e:
        print(f"erro iniciando/configurando o kafka: {str(e)}")

    return iniciado

@servico.get("/")
def get_info():
    return Response(json.dumps(INFO), status=200, mimetype="application/json")

@servico.post("/vender")
def vender():
    sucesso, id, dados = False, secrets.token_hex(16), request.json

    # aqui teria a lógica de validação de dados e inicio do processamento da venda
    sleep(2)

    try:
        venda = {
            "id": id,
            "sucesso": 1,
            "mensagem": "venda de ebook iniciada",
            "id_cliente": dados["id_cliente"],
            "id_ebook": dados["id_ebook"],
            "quantidade": dados["quantidade"]
        }

        produtor = KafkaProducer(bootstrap_servers = ["kafka:29092"], api_version=(0, 10, 1))
        produtor.send(topic=PROCESSO, value=json.dumps(venda).encode("utf-8"))
        produtor.flush()
        produtor.close()

        sucesso = True
    except Exception as e:
        print(f"erro realizando venda de ebook: {str(e)}")

    return Response(status=204 if sucesso else 422)

if __name__ == "__main__":
    iniciado = iniciar()
    if iniciado:
        servico.run(host="0.0.0.0", debug=True)
    else:
        print("erro iniciando venda de ebook")